Ansible demo playbooks.

