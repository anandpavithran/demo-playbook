#!/bin/bash
echo "Hello there!! Welcome to `hostname`"
exit 0
