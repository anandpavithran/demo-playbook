#!/bin/bash
for i in httpd vsftpd dialog
do
echo $i
done
